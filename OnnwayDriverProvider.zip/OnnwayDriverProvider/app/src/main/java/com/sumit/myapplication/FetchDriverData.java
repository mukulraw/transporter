package com.sumit.myapplication;

public class FetchDriverData {

    //a type of POJO class for fetching the driver location
    public Integer bId;
}
