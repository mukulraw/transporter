package com.sumit.myapplication.OrderStatus;

public class AssignTruckData {

    public String bookingId;
    public String truckNumber;
    public String driverMobNumber;
}
