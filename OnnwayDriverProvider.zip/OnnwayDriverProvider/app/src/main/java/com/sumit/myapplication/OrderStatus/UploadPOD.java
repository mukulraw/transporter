package com.sumit.myapplication.OrderStatus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.sumit.myapplication.R;

public class UploadPOD extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_pod);
    }
}
