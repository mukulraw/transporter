package com.sumit.myapplication;

public class PostTruckDataDetails {
    public String mobile_no;
    public String type;
    public String source;
    public String destination;
    public String vehicle_type;
    public String sch_date;
}
