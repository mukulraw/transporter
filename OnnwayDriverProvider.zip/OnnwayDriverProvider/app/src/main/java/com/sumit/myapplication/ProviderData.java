package com.sumit.myapplication;

public class ProviderData {

    public String mobile_number;
    public String name;
    public String type;
    public String transport_name;
    public String city;
}
