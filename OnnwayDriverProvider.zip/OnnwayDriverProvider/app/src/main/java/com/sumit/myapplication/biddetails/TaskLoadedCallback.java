package com.sumit.myapplication.biddetails;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
