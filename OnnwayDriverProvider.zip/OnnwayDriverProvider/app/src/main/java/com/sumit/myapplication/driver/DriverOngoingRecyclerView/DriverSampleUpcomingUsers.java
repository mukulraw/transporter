package com.sumit.myapplication.driver.DriverOngoingRecyclerView;

import java.util.List;

public class DriverSampleUpcomingUsers {
    public  static List<DriverUpcomingUsers> sampleupcominguserdriver = null;
}
