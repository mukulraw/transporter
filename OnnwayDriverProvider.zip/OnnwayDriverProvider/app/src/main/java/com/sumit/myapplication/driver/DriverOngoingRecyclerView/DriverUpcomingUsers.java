package com.sumit.myapplication.driver.DriverOngoingRecyclerView;

public class DriverUpcomingUsers {

    public String upComingIdDriver;
    public String upComingDateDriver;
    public String upComingTypeDriver;
    public String upComingStartLocDriver;
    public String upComingEndLocDriver;
    public String upComingMaterialTypeDriver;
    public String upComingWeightDriver;
    public String upComingTotalAmountDriver;
    public String upComingDueAmountDriver;
    public String upComingStatusDriver;
    public String upComingTruckNumberDriver;
    public String upComingDeliveryAddressDriver;
}
