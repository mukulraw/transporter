package com.sumit.myapplication.driver.driver.past.order.recycler.view;

public class PastUsers {

    public String pastIdDriver;
    public String pastDateDriver;
    public String pastTypeDriver;
    public String pastStartLocDriver;
    public String pastEndLocDriver;
    public String pastMaterialTypeDriver;
    public String pastWeightDriver;
    public String pastTotalAmountDriver;
    public String pastDueAmountDriver;
    public String pastStatusDriver;
    public String pastTruckNumberDriver;
    public String pastDeliveryAddressDriver;

}
