package com.sumit.myapplication.driver.driver.past.order.recycler.view;

import java.util.List;

public class SamplePastUsers {
    public  static List<PastUsers> samplepastuser = null;
}
