package com.sumit.myapplication.driver.driver.posted.truck.recyclerview;

import java.util.List;

public class SamplePostedTruck {
    public  static List<PostedUser> sampleposteduser=null;
}
