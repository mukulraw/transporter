package com.sumit.myapplication.driver.ongoingorderdriverlocation;

public class OngoingOrderDriverLocation {

    //A type of POJO class for updating the latitude and longitude of the driver
    public Integer bookingId;
    public double driverLatitude;
    public double driverLongitude;

}
