package com.sumit.myapplication.driver.profilerelated.DriverOperatedRoutesRecyclerView;

public class AddRoutesDataDetails {
    public String mobile_no;
    //public String type;
    public String source;
    public String destination;
}
