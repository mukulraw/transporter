package com.sumit.myapplication.driver.profilerelated.DriverOperatedRoutesRecyclerView;

public class DriverOperatedRoutesUser {
    public String operatedRouteSourceDriver;
    public String operatedRouteDestinationDriver;



}
