package com.sumit.myapplication.driver.profilerelated.DriverOperatedRoutesRecyclerView;

import java.util.List;

public class SampleOperatedRoutesDriver {
public static List<DriverOperatedRoutesUser> sampleOperatedRoutes=null;
}
