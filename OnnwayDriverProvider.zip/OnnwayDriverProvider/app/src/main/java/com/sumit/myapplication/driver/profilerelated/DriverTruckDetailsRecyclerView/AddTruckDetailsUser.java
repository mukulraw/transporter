package com.sumit.myapplication.driver.profilerelated.DriverTruckDetailsRecyclerView;

public class AddTruckDetailsUser {
    public String mobile_no;
    public String type;
    public String truckType;
    public String reg_no;
    public String driverName;
    public String driverNumber;
}
