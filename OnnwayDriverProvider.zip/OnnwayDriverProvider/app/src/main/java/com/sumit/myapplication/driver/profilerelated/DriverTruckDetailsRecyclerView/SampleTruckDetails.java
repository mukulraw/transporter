package com.sumit.myapplication.driver.profilerelated.DriverTruckDetailsRecyclerView;

import java.util.List;

public class SampleTruckDetails {
    public static List<TruckDetailsUser> sampleTruckDetails=null;
}
