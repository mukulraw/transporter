package com.sumit.myapplication.driver.profilerelated.DriverTruckDetailsRecyclerView;

public class TruckDetailsUser {
    public String truckType;
    public String registrationNumber;
    public String driverName;
    public String driverNumber;

}
