package com.sumit.myapplication.driver.profilerelated.changecity;

public class ChangeCityDetails {
    public String driverMobile;
    public String driverChangedCity;
}
