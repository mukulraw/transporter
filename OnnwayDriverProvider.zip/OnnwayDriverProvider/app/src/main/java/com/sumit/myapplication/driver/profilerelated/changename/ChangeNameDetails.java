package com.sumit.myapplication.driver.profilerelated.changename;

public class ChangeNameDetails {
    public String driverMobile;
    public String driverChangedName;
}
