package com.sumit.myapplication.driver.profilerelated.changephone;

public class ChangePhoneDetails {
    public String driverMobile;
    public String driverChangedPhone;
}
