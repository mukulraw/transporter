package com.sumit.myapplication.otp;

public class CheckingPreRegistered {
    public String entered_mobile;
}
