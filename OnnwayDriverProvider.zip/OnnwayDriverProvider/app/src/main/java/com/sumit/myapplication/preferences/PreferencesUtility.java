package com.sumit.myapplication.preferences;

/**
 * Created by atul
 */

public class PreferencesUtility {

    // Values for Shared Prefrences
    public static final String LOGGED_IN_PREF = "logged_in_status";
    public static final String PHONE_NUMBER = "phone_no_status";
    public static final String COUNTER_LOADING_BID="Nothing Loaded";
    public static final String COUNTER_LOADING_POSTED_TRUCK="Nothing Loaded";
    public static final String COUNTER_LOADING_UPCOMING="Nothing Loaded";
    public static final String COUNTER_LOADING_PAST = "Nothing Loaded";

}