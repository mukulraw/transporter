package com.sumit.myapplication.profilerelated.OperatedRoutesSampleUser;

public class AddRoutesdataDetailsProvider {
    public String mobile_no_provider;
    //public String type;
    public String source_provider;
    public String destination_provider;
}
