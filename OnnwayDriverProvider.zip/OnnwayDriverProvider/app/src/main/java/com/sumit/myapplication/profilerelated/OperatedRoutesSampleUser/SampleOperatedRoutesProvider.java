package com.sumit.myapplication.profilerelated.OperatedRoutesSampleUser;

import com.sumit.myapplication.profilerelated.OperatedRoutesUserProvider;

import java.util.List;

public class SampleOperatedRoutesProvider {
    public static List<OperatedRoutesUserProvider> sampleOperatedRoutesProviders=null;

}
