package com.sumit.myapplication.profilerelated;

public class OperatedRoutesUserProvider {
    public String operatedRouteSourceProvider;
    public String operatedRouteDestinationProvider;

}
