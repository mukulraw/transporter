package com.sumit.myapplication.profilerelated.changeprovidercity;

public class ChangeProviderCityDetails {
    public String providerCurrentMobile;
    public String providerChangedCity;
}
