package com.sumit.myapplication.profilerelated.changeprovidermobile;

public class ChangeProviderMobileDetails {
    public String providerCurrentMobile;
    public String providerChangedMobile;
}
