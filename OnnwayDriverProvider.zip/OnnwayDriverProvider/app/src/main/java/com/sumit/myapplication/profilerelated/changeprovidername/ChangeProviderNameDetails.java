package com.sumit.myapplication.profilerelated.changeprovidername;

public class ChangeProviderNameDetails {
    public String providerCurrentMobile;
    public String providerChangedName;
}
