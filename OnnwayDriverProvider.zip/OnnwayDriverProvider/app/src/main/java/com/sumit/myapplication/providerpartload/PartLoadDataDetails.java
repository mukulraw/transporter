package com.sumit.myapplication.providerpartload;

public class PartLoadDataDetails {

    public String part_mobile_no;
    public String part_user_type;
    public String part_source_add;
    public String part_dest_add;
    public String part_vehicle_type;
    public String part_sch_date;
    public String part_material_type;
    public String part_rem_payload;
    public String part_rem_payload_unit;
    public String part_rem_len;
    public String part_rem_len_unit;
    public String part_rem_wid;
    public String part_rem_wid_unit;
    public String part_rem_hei;
    public String part_rem_hei_unit;
    public String part_box1;
    public String part_box2;
    public String part_box3;
    public String part_box4;
    public String part_box5;
    public String part_box6;
    public String part_box7;
    public String part_box8;

}
