package com.sumit.myapplication.recyclerview;

public class BidUser
{
    public String truckType;
    public String material;
    public String weight;
    public String source;
    public String destination;
    public String date;
    public String sourceLat;
    public String sourceLng;
    public String destLat;
    public String destLng;
}
