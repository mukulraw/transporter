package com.sumit.myapplication.recyclerview;

public class PastOrder {
    public String pastId;
    public String pastDate;
    public String pastType;
    public String pastStartLoc;
    public String pastEndLoc;
    public String pastMaterialType;
    public String pastWeight;
    public String pastTotalAmount;
    public String pastDueAmount;
    public String pastStatus;
    public String pastTruckNumber;
    public String pastDeliveryAddress;
}
