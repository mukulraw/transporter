package com.sumit.myapplication.recyclerview;

public class PostedUser {

    public String postedTruckDate;
    public String postedTruckType;
    public String postedTruckStartLoc;
    public String postedTruckEndLoc;

}
