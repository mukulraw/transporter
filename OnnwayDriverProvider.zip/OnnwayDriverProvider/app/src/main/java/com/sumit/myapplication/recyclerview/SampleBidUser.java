package com.sumit.myapplication.recyclerview;

import java.util.List;

public class SampleBidUser {
    public static List<BidUser> samplebiduser = null;
}
