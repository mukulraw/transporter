package com.sumit.myapplication.recyclerview;

import java.util.List;

public class SamplePastOrder {
    public static List<PastOrder> pastOrders = null;
}
