package com.sumit.myapplication.recyclerview;

import java.util.List;

public class SamplePostedTruck {
    public  static List<PostedUser> sampleposteduser=null;
}
