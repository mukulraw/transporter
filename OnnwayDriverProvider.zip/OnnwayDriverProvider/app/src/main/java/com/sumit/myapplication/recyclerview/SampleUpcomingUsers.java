package com.sumit.myapplication.recyclerview;

import java.util.List;

public class SampleUpcomingUsers {
    public  static List<UpcomingUsers> sampleupcominguser=null;
}
