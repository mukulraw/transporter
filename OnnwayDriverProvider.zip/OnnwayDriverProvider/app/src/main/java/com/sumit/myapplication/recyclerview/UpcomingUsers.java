package com.sumit.myapplication.recyclerview;

public class UpcomingUsers {

    public String upComingId;
    public String upComingDate;
    public String upComingtype;
    public String upComingStartLoc;
    public String upComingEndLoc;
    public String materialType;
    public String upComingWeight;
    public String upComingTotalAmount;
    public String upComingDueAmount;
    public String upComingStatus;
    public String upComingTruckNumber;
    public String upComingDeliveryAddress;
}
