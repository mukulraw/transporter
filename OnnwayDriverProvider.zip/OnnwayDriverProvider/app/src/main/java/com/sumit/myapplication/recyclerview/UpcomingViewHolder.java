package com.sumit.myapplication.recyclerview;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.sumit.myapplication.R;

public class UpcomingViewHolder extends RecyclerView.ViewHolder
{
    public TextView upComingDate,upComingtype,
            upComingStartLoc,upComingEndLoc
            ,materialType,upComingWeight,
            upComingTotalAmount,upComingDueAmount;

    public CardView upcomingOrderCard;

    public UpcomingViewHolder(@NonNull View itemView) {
        super(itemView);
        upcomingOrderCard = itemView.findViewById(R.id.posted_truck_recycler_card_id);

        upComingDate=itemView.findViewById(R.id.upcoming_date);
        upComingtype=itemView.findViewById(R.id.upcoming_type);
        upComingStartLoc=itemView.findViewById(R.id.upcoming_start_loc);
        upComingEndLoc=itemView.findViewById(R.id.upcoming_end_loc);
        materialType=itemView.findViewById(R.id.upcoming_material_type);
        upComingWeight=itemView.findViewById(R.id.upcoming_material_weight);
        upComingTotalAmount=itemView.findViewById(R.id.upcoming_total_amount);
        upComingDueAmount=itemView.findViewById(R.id.upcoming_due_amount);


    }
}
