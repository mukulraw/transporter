package com.sumit.myapplication.tablayout;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.sumit.myapplication.networking.Post;
import com.sumit.myapplication.recyclerview.PastOrderRecyclerAdapter;
import com.sumit.myapplication.recyclerview.SamplePastOrder;
import com.sumit.myapplication.preferences.SaveSharedPreference;
import com.sumit.myapplication.R;

public class PastFragment extends Fragment
{
    View view;
    PastOrderRecyclerAdapter pastOrderRecyclerAdapter;
    SwipeRefreshLayout swipeRefreshLayout;

    String up[]={"hello","hello"};
    private RecyclerView recyclerView;

    public static String bId;

    static Activity activity;

    public PastFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.past_order_fragment,container,false);

        recyclerView = view.findViewById(R.id.recycler_view_past_order);

        swipeRefreshLayout=view.findViewById(R.id.swipe_refresh_layout_past);

        activity = (Activity) view.getContext();

        if(SaveSharedPreference.getCounterPostedStatus(getContext()).equals("0")) {
            Toast.makeText(getContext(), "1st block", Toast.LENGTH_SHORT).show();
            new Post().doPast(getContext(),recyclerView);
        }
        else {
            if(SamplePastOrder.pastOrders == null) {
                Toast.makeText(getContext(), "2nd block", Toast.LENGTH_SHORT).show();
                new Post().doPast(getContext(),recyclerView);
            }else
            {
                Toast.makeText(getContext(), "3rd block", Toast.LENGTH_SHORT).show();
                setRecyclerBid();
            }
        }

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Post().doPast(getContext(),recyclerView);
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        return view;
    }

    public void setRecyclerBid()
    {
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        pastOrderRecyclerAdapter = new PastOrderRecyclerAdapter(SamplePastOrder.pastOrders);
        recyclerView.setAdapter(pastOrderRecyclerAdapter);
    }

    public static void enableBottomSheet(final String bid, String totalAmount, String orderStatus, String truckNumber, String deliveryAddress, String orderStatusButton) {
        bId = bid;
    }
}

